=head1 SYNOPIS

 test test test

=cut

package AMZ::Test;

$VERSION = 1;
